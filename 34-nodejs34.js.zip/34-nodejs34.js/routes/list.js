var express = require('express');
var router = express.Router();
const fs = require('fs');
const path = require('path');


/* GET users listing. */
router.get('/', function(req, res, next) {
  listModel.find().then(dataArr =>{
    res.render('list',{title:'事项列表展示',dataArr});
  });
});

module.exports = router;
