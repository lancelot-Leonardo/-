var express = require('express');
var router = express.Router();
const fs = require('fs');
const path = require('path');
const shortid = require('shortid');
const listModel = require('../models/list');

/* GET home page. */
// 日志数据
/* const dayRecord = {
  arr: []
} */
// L爆了，肯定要写json文件里面，这一刷新就没了

// 中间件声明
const formGet = express.urlencoded({ extended: false });

// 路由规则及其路由处理函数
router.get('', function (req, res, next) {
  res.render('add.ejs', { title: '添加消费日志' });
});
router.post('/submit', formGet, function (req, res) {
  const { task, time, type, amount, note } = req.body;
  listModel.create({
    task,
    time,
    type,
    amount,
    note
  }).then(() =>{
    res.send();
  }).catch((err) =>{
    console.log(err);
  });
});
router.post('/delete/:id',(req,res) =>{
  listModel.deleteOne({_id:req.params.id}).then(data => {
    console.log(data);
  }).catch(err =>{
    console.log(err);
  });
});

module.exports = router;
